#include <cassert>
#include "../firmware/s3_integral/GuardiaROS.h"
#include "../firmware/s3_integral/Navegacion.h"

int main() {
  GuardiaROS guardia;
  assert(!guardia.vigente(0));
  assert(!guardia.aceptar({2, 1, 10, 1, 0}, 1, 10, false, true));
  assert(!guardia.aceptar({1, 1, 10, 1, 0}, 1, 261, false, true));
  assert(!guardia.aceptar({1, 1, 10, 1, 0}, 1, 15, false, false));
  assert(!guardia.aceptar({1, 1, 10, 1, 0}, 1, 15, false, true));
  assert(guardia.aceptar({1, 2, 15, 1, -1}, 1, 16, false, true));
  assert(guardia.preferencia == -1);
  assert(!guardia.aceptar({1, 3, 40, 1, 0}, 1, 41, true, true));
  assert(guardia.aceptar({1, 4, 100, 0, 1}, 1, 100, true, true));
  assert(guardia.vigente(999) && !guardia.vigente(1000));
  assert(!guardia.aceptar({1, 5, 1000, 0, 1}, 1, 1000, true, true));
  guardia.parar();
  assert(!guardia.aceptar({1, 6, 1100, 0, 1}, 1, 1100, false, true));
  assert(guardia.aceptar({1, 7, 1100, 1, 0}, 1, 1100, false, true));
  guardia.parar();
  assert(!guardia.vigente(1100));

  Navegacion nav;
  const ConfigNavegacion config{0, 150, true, false};
  uint16_t mapa[72];
  for (auto &d : mapa) d = 1500;
  nav.preferenciaROS = -1;
  assert(nav.elegirLado(mapa, config) == -1);
  for (int i = 4; i < 20; ++i) mapa[i] = 1800;
  assert(nav.elegirLado(mapa, config) == 1);
  mapa[0] = mapa[1] = 0;
  assert(nav.evaluar(mapa, config, true));
  mapa[0] = 120;
  assert(nav.evaluar(mapa, config));
}
