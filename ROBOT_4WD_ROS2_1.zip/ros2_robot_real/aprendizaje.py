"""Aprendizaje de giro: compara resultados observados en espacios equivalentes."""

import json
from pathlib import Path


class Giros:
    def __init__(self, ruta):
        self.ruta = Path(ruta)
        try:
            anterior = json.loads(self.ruta.read_text(encoding="utf-8"))
            self.historial = {
                contexto: {lado: [max(0, int(n)) for n in anterior[contexto][lado]]
                           for lado in ("1", "-1")}
                for contexto in self.contextos()
            }
            if any(len(v) != 2 for grupo in self.historial.values() for v in grupo.values()):
                raise ValueError("Formato de aprendizaje inválido")
        except (OSError, ValueError, KeyError, TypeError):
            self.historial = self.contextos()
        self.corrida = None
        self.intento = None

    @staticmethod
    def contextos():
        return {c: {"1": [0, 0], "-1": [0, 0]} for c in ("estrecho", "amplio")}

    @staticmethod
    def contexto(d):
        izq, der = d["espacioIzq"], d["espacioDer"]
        if not d["lidar"] or min(izq, der) < 1 or abs(izq - der) > 100:
            return None
        return "estrecho" if min(izq, der) < 700 else "amplio"

    def preferencia(self, d):
        contexto = self.contexto(d)
        if not contexto:
            return 0
        historial = self.historial[contexto]
        # Una muestra de cada lado y luego la mayor tasa de éxito suavizada.
        if not sum(historial["1"]):
            return 1
        if not sum(historial["-1"]):
            return -1
        return max((1, -1), key=lambda lado: (
            (historial[str(lado)][0] + 1) / (sum(historial[str(lado)]) + 2)))

    def observar(self, d):
        corrida = (d["sesion"], d["corrida"])
        if corrida != self.corrida or not d["corrida"] or not d["lidar"]:
            self.corrida = corrida
            self.intento = None
        if not d["corrida"] or not d["lidar"]:
            return None
        fase, lado = d["fase"], d["giro"]
        resultado = None
        if self.intento and self.intento[2]:
            contexto, anterior, _ = self.intento
            if fase == 1 or (fase == 2 and lado != anterior):
                exito = fase == 1
                self.historial[contexto][str(anterior)][0 if exito else 1] += 1
                resultado = {"contexto": contexto, "lado": anterior, "salida": exito,
                             "historial": self.historial}
                self.intento = None
        if fase == 2 and self.intento is None:
            contexto = self.contexto(d)
            if contexto and lado in (-1, 1):
                self.intento = (contexto, lado, False)
        elif fase in (3, 4) and self.intento and self.intento[1] == lado and d["moviendo"]:
            self.intento = (self.intento[0], lado, True)
        elif fase in (0, 1, 5, 6, 7):
            self.intento = None
        if resultado:
            temporal = self.ruta.with_suffix(".tmp")
            temporal.write_text(json.dumps(self.historial) + "\n", encoding="utf-8")
            temporal.replace(self.ruta)
        return resultado
